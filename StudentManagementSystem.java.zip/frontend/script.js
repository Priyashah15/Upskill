const API_URL = "http://localhost:5000/students";

document.getElementById("studentForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const student = {
        name: document.getElementById("name").value,
        rollNumber: document.getElementById("rollNumber").value,
        course: document.getElementById("course").value,
        email: document.getElementById("email").value,
    };
    await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(student),
    });
    loadStudents();
});

async function loadStudents() {
    const res = await fetch(API_URL);
    const students = await res.json();
    const list = document.getElementById("studentList");
    list.innerHTML = "";
    students.forEach(s => {
        const li = document.createElement("li");
        li.textContent = `${s.name} (${s.rollNumber}) - ${s.course} - ${s.email}`;
        list.appendChild(li);
    });
}
loadStudents();
